# UPDRS OCR App

Esta aplicación permite extraer puntuaciones del formulario MDS-UPDRS desde una imagen usando OCR y exportarlas a Excel.

## ¿Cómo desplegar esta app en Streamlit Cloud?

1. Subí estos archivos a un repositorio público en GitHub.
2. Andá a [https://streamlit.io/cloud](https://streamlit.io/cloud).
3. Iniciá sesión con GitHub y seleccioná tu repositorio.
4. Indicá que el archivo principal es `app.py`.
5. ¡Listo! Tu app quedará disponible para subir imágenes y descargar los resultados.
